## BOT WHATSAPP
APASIH KONTOL







## CARA INSTALL
# TERMUX
```bash
> download termux
> buka
> pkg install git
> pkg install ffmpeg
> pkg install nodejs
> apt update && apt upgrade
> git clone https://github.com/WhyEtzz/Botnjay
> cd Botnjay
> npm i -g cwebp && npm i -g ytdl
> npm i && npm i got
> bash install.sh
> node index.js
```


# FITUR

| KEADAAN       |               FITUR     |
| :-----------: | :--------------------------------:  |
|       ✅       |    PANTUN                         |
|       ✅       | ANIMEPICT                         |
|       ✅       | STICKER                           |
|       ✅       | NULIS                             |
|       ✅       | QUOTES                            |
|       ✅       | RANDOM PICT                       |
|       ✅       | ANIMEPICT                         |
|       ✅       | LIRIK                             |
|       ✅       | ALAY                              |
|       ✅       | YT,YTMP3,IG,TWT DOWNLOADER        |
|       ✅       | WIKIPEDIA                         |
|       ✅       | ARTI NAMA                         |
|       ✅       | SHOLAT                            |
|       ✅       | QURAN                             |
|       ✅       | SSWEB                        |

ket : ✅ : aktif




## THANKS TO
* [`termux-whatsapp-bot`](https://github.com/fdciabdul/termux-whatsapp-bot)

## DONASI
* TRAKTEER : https://trakteer.id/BotEtzz
